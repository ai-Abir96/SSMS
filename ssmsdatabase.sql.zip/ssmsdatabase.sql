-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2019 at 01:47 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ssmsdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ct_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ct_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `ct_name`, `ct_description`, `created_at`, `updated_at`) VALUES
(1, 'Fruits & Vegetables', 'Fruits, Vegetables', NULL, '2019-12-29 23:28:41'),
(2, 'Meat & Fish', 'Meat & Fish', NULL, NULL),
(3, 'Drinks', 'Drinks', NULL, NULL),
(4, 'Electronics', 'Electronics', NULL, NULL),
(5, 'Fashion', 'Fashion(Tshirts,Pants etc)', NULL, NULL),
(6, 'Snacks', 'Snacks', NULL, NULL),
(7, 'Dairy', 'Milk, Cheese etc', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `c_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `c_phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `c_name`, `c_email`, `c_phone`, `c_address`, `created_at`, `updated_at`) VALUES
(1, 'Md Fahim Hossain', NULL, '01832229152', 'Khilkhet', '2019-12-31 00:33:16', '2019-12-31 00:33:16'),
(2, 'Md rimu', NULL, '0151254534', 'Khilkhet dhaka', '2019-12-31 00:35:01', '2019-12-31 00:35:01'),
(3, 'Rimu', NULL, '015566444', 'mirpur dhaka', '2019-12-31 00:36:45', '2019-12-31 00:36:45');

-- --------------------------------------------------------

--
-- Table structure for table `emp_infos`
--

CREATE TABLE `emp_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `emp_user_id` bigint(20) UNSIGNED NOT NULL,
  `emp_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_fname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_lname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_phone1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_phone2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_nid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_birth_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_age` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_blood` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_preaddress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_peraddress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_marital_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ec_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ec_phone1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ec_phone2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ec_relation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ec_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emp_jobs`
--

CREATE TABLE `emp_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `emp_id` bigint(20) UNSIGNED NOT NULL,
  `position_id` bigint(20) UNSIGNED NOT NULL,
  `salary` int(11) NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signing_date` date NOT NULL,
  `departing_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `emp_jobs`
--

INSERT INTO `emp_jobs` (`id`, `emp_id`, `position_id`, `salary`, `status`, `signing_date`, `departing_date`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 15000, 'Active', '2019-05-08', NULL, '2019-12-29 17:25:41', NULL),
(3, 2, 1, 12500, 'Active', '1996-08-19', NULL, '2019-12-29 17:41:15', NULL),
(4, 3, 2, 8000, 'On Leave', '2019-12-11', NULL, '2019-12-29 17:41:48', NULL),
(5, 4, 2, 8000, 'On Leave', '2019-12-01', NULL, '2019-12-29 17:42:45', '2019-12-30 23:46:45');

-- --------------------------------------------------------

--
-- Table structure for table `emp_positions`
--

CREATE TABLE `emp_positions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `emp_positions`
--

INSERT INTO `emp_positions` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '2019-11-14 09:05:35', '2019-11-14 10:59:25'),
(2, 'Salesman', '2019-11-14 09:06:21', '2019-11-14 09:35:02');

-- --------------------------------------------------------

--
-- Table structure for table `e_contact_infos`
--

CREATE TABLE `e_contact_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ec_user_id` bigint(20) UNSIGNED NOT NULL,
  `emp_phone1` int(11) NOT NULL,
  `emp_phone2` int(11) NOT NULL,
  `emp_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_preaddress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_peraddress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `e_contact_infos`
--

INSERT INTO `e_contact_infos` (`id`, `ec_user_id`, `emp_phone1`, `emp_phone2`, `emp_email`, `emp_preaddress`, `emp_peraddress`, `created_at`, `updated_at`) VALUES
(1, 1, 1515297427, 1515297427, 'azizulabir1610@gmail.com', 'Dhaka Cantonment , Dhaka', 'Kushtia, Bangladesh', '2019-12-29', NULL),
(2, 2, 1521326372, 1521326372, 'rimu@gamil.com', 'KhilKhet, Dhaka', 'Bagura,Bangladesh', '2019-12-29', NULL),
(3, 3, 1910527513, 1910527513, 'fahim@gmail.com', 'KhilKhet, Dhaka', 'Bhola, Bangladesh', '2019-12-29', NULL),
(4, 4, 1521320834, 1521320834, 'shanto@gmail.com', 'Mirpur, Dhaka', 'Tangail, Bangladesh', '2019-12-29', NULL),
(5, 5, 561, 354, 'rakibhasan@gmail.com', 'sdf', 'fdgg', '2019-12-31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `e_emergancy_infos`
--

CREATE TABLE `e_emergancy_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ee_user_id` bigint(20) UNSIGNED NOT NULL,
  `ec_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ec_phone1` int(11) NOT NULL,
  `ec_phone2` int(11) NOT NULL,
  `ec_relation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ec_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `e_emergancy_infos`
--

INSERT INTO `e_emergancy_infos` (`id`, `ee_user_id`, `ec_name`, `ec_phone1`, `ec_phone2`, `ec_relation`, `ec_address`, `created_at`, `updated_at`) VALUES
(1, 1, 'Md Nazrul Islm', 1515297427, 1515297427, 'Father', 'Dhaka Cantonment, Dhaka', '2019-12-29', NULL),
(2, 2, 'Md Fahim', 1521326372, 1521326372, 'Brother', 'Khilkhet, Dhaka', '2019-12-29', NULL),
(3, 3, 'Md Rashaduzzaman', 1521326372, 1521326372, 'Brother', 'Khilkhet, Dhaka', '2019-12-29', NULL),
(4, 4, 'Md Fahim', 1521320834, 1521320834, 'Brother', 'Khilkhet, Dhaka', '2019-12-29', NULL),
(5, 5, 'sdf', 234, 234, 'dsf', 'sdf', '2019-12-31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `e_personal_infos`
--

CREATE TABLE `e_personal_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ep_user_id` bigint(20) UNSIGNED NOT NULL,
  `emp_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_fname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_lname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_nid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_birth_date` date NOT NULL,
  `emp_age` int(11) NOT NULL,
  `emp_blood` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emp_marital_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `e_personal_infos`
--

INSERT INTO `e_personal_infos` (`id`, `ep_user_id`, `emp_image`, `emp_fname`, `emp_lname`, `employee_nid`, `emp_birth_date`, `emp_age`, `emp_blood`, `emp_marital_status`, `created_at`, `updated_at`) VALUES
(1, 1, '1.png', 'Azizul Islam', 'Abir', '5552198128', '1996-09-05', 23, 'AB+', 'In a relationship', '2019-12-29', '2019-12-29'),
(2, 2, '2.jpg', 'Md Rashaduzzaman', 'Rimu', '5552198152', '1996-09-07', 23, 'A+', 'Unmarried', '2019-12-29', '2019-12-29'),
(3, 3, '3.jpg', 'Md Fahim', 'Hossain', '5219195275', '1992-05-19', 27, 'B+', 'Unmarried', '2019-12-29', '2019-12-29'),
(4, 4, '4.jpg', 'Khandaker Jamiul Islam', 'Shanto', '5159192857', '1996-05-09', 23, 'B+', 'In a relationship', '2019-12-29', '2019-12-29'),
(5, 5, '5.JPG', 'Rakib', 'Hasan', '654654', '2019-12-31', 0, 'a+', 'Married', '2019-12-31', '2019-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(25, '2014_10_12_000000_create_users_table', 1),
(26, '2014_10_12_100000_create_password_resets_table', 1),
(27, '2019_08_19_000000_create_failed_jobs_table', 1),
(28, '2019_11_09_153603_create_roles_table', 1),
(29, '2019_11_09_154121_create_role_user_table', 1),
(30, '2019_11_13_112607_create_emp_positions_table', 1),
(53, '2019_11_18_175056_create_categories_table', 4),
(63, '2019_11_18_174812_create_suppliers_table', 9),
(79, '2019_11_18_175030_create_products_table', 11),
(86, '2019_11_30_075049_create_customers_table', 13),
(109, '2019_12_13_202222_create_orders_table', 20),
(117, '2019_11_18_194832_create_sub_categories_table', 25),
(122, '2019_12_09_164754_create_return_products_table', 27),
(123, '2019_12_10_183424_create_e_personal_infos_table', 28),
(124, '2019_12_10_183540_create_e_contact_infos_table', 28),
(125, '2019_12_10_183600_create_e_emergancy_infos_table', 28),
(126, '2019_11_14_173907_create_emp_infos_table', 29),
(128, '2019_11_16_144947_create_emp_jobs_table', 30),
(129, '2019_11_18_181624_create_stocks_table', 31),
(130, '2019_11_30_180351_create_orderdetails_table', 32);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `unitprice` double(8,2) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `amount` double(8,2) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `order_id`, `product_id`, `quantity`, `unitprice`, `discount`, `amount`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 5, 30.00, 0, 150.00, '2019-12-31', '2019-12-31'),
(2, 1, 6, 1, 110.00, 0, 110.00, '2019-12-31', '2019-12-31'),
(3, 1, 7, 1, 500.00, 0, 500.00, '2019-12-31', '2019-12-31'),
(4, 1, 8, 1, 310.00, 0, 310.00, '2019-12-31', '2019-12-31'),
(5, 1, 9, 2, 15.00, 0, 30.00, '2019-12-31', '2019-12-31'),
(6, 2, 5, 5, 30.00, 0, 150.00, '2019-12-31', '2019-12-31'),
(7, 3, 6, 4, 110.00, 0, 440.00, '2019-12-31', '2019-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `totalamount` float(11,2) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `customer_id`, `totalamount`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 1100.00, '2019-12-31', '2019-12-31'),
(2, 1, 2, 150.00, '2019-12-31', '2019-12-31'),
(3, 1, 3, 440.00, '2019-12-31', '2019-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('rimu@gamil.com', '$2y$10$jGpH2qXeCDhJGL5jxDqWTeAnPtxQSkEcd0uyejg9xZd4IQ9IrqH8K', '2019-12-30 16:14:42'),
('azizulabir1610@gmail.com', '$2y$10$Yg076SrVIHcKCSlRsWGDjukfuLcDGS8B/ay7K7Yw7xNrZoiR.pfwC', '2019-12-30 16:16:05');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sp_id` bigint(20) UNSIGNED NOT NULL,
  `p_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_price` float(10,2) DEFAULT NULL,
  `p_discount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `sp_id`, `p_image`, `p_price`, `p_discount`, `created_at`, `updated_at`) VALUES
(1, 5, '1.jpg', 30.00, '0', NULL, '2019-12-30 00:38:25'),
(3, 6, '3.jpg', 110.00, '0', NULL, '2019-12-30 00:39:08'),
(4, 7, '4.jpg', 500.00, '5', NULL, '2019-12-31 00:44:11'),
(5, 8, '5.jpg', 310.00, '0', NULL, '2019-12-30 00:40:12'),
(6, 9, '6.jpg', 15.00, '0', NULL, '2019-12-30 00:40:44'),
(8, 10, '8.jpeg', 30.00, '0', '2019-12-30 00:41:20', '2019-12-30 00:41:20'),
(10, 14, '10.jpg', 25.00, '0', '2019-12-30 00:42:32', '2019-12-30 00:42:32'),
(11, 15, '11.jpeg', 40.00, '0', '2019-12-30 00:43:12', '2019-12-30 00:43:29'),
(12, 16, '12.jpg', 42.00, '0', '2019-12-30 00:43:54', '2019-12-30 00:43:54'),
(13, 17, '13.jpg', 30.00, '0', '2019-12-30 00:44:33', '2019-12-30 00:44:33'),
(14, 18, '14.jpg', 10.00, '0', '2019-12-30 00:45:33', '2019-12-30 00:45:33'),
(15, 19, '15.jpg', 10.00, '0', '2019-12-30 00:47:55', '2019-12-30 00:47:55'),
(16, 20, '16.jpg', 15.00, '0', '2019-12-30 00:48:12', '2019-12-30 00:48:12'),
(17, 21, '17.jpg', 280.00, '0', '2019-12-30 00:48:54', '2019-12-30 00:48:54'),
(18, 22, '18.jpeg', 65.00, '0', '2019-12-30 00:49:17', '2019-12-30 00:49:17'),
(19, 12, '19.webp', 80.00, '0', '2019-12-31 00:05:11', '2019-12-31 00:05:11');

-- --------------------------------------------------------

--
-- Table structure for table `return_products`
--

CREATE TABLE `return_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `seller_id` bigint(20) UNSIGNED NOT NULL,
  `refunder_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `unitprice` double(10,2) NOT NULL,
  `discount` int(10) NOT NULL,
  `cause` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` float(11,2) NOT NULL,
  `total` float(11,2) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `return_products`
--

INSERT INTO `return_products` (`id`, `order_id`, `customer_id`, `seller_id`, `refunder_id`, `product_id`, `unitprice`, `discount`, `cause`, `quantity`, `amount`, `total`, `created_at`, `updated_at`) VALUES
(1, 2, 2, 2, 1, 5, 30.00, 0, 'damaged', 50, 1500.00, 1500.00, '2019-12-30', '2019-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', NULL, NULL),
(2, 'Salesman', '2019-11-18 04:04:51', '2019-11-18 04:04:51');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`role_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL),
(1, 2, NULL, NULL),
(2, 3, NULL, NULL),
(2, 4, NULL, NULL),
(2, 5, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `p_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fcat_id` bigint(20) UNSIGNED NOT NULL,
  `fscat_id` bigint(20) UNSIGNED NOT NULL,
  `fsup_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `st_price` double(8,2) DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `p_code`, `p_name`, `fcat_id`, `fscat_id`, `fsup_id`, `quantity`, `st_price`, `description`, `created_at`, `updated_at`) VALUES
(5, 'DF10002', 'Peanuts(100gm)', 1, 1, 1, 990, 30.00, 'Price : per 100gram,    Quantity: 100gram 1 packet', NULL, '2019-12-31 00:35:01'),
(6, 'MM20001', 'Chicken(Poultry)(kg)', 2, 3, 1, 35, 110.00, 'Price : per 1000gram,    Quantity: 1000gram 1 packet', NULL, '2019-12-31 00:36:45'),
(7, 'MM20002', 'Beef(kg)', 2, 3, 1, 19, 480.00, 'Price : per 1kg,    Quantity: 1kg 1 packet', NULL, '2019-12-31 00:33:16'),
(8, 'MM20003', 'Chicken (boneless brest)(kg)', 2, 3, 1, 49, 305.00, 'Price : per 1kg,    Quantity: 1kg 1 packet', NULL, '2019-12-31 00:33:16'),
(9, 'DS30001', 'Pepsi (250ml)', 3, 5, 5, 493, 14.00, 'Price : per 250ml,    Quantity: 250ml1 bottle', NULL, '2019-12-31 00:33:16'),
(10, 'DS30002', 'Pepsi (500ml)', 3, 5, 5, 500, 28.00, 'Price : per 500ml,    Quantity: 500ml1 bottle', NULL, '2019-12-29 17:23:53'),
(12, 'DS30003', 'Pepsi (2000ml)', 3, 5, 5, 0, 78.00, 'Price : per2000ml,    Quantity: 2000ml1 bottle', NULL, '2019-12-30 14:08:10'),
(13, 'FV13001', 'Onion(China)(1kg)', 1, 14, 2, 0, 45.00, 'Price : per 1000gram,    Quantity: 1000gram 1 packet', '2019-12-29 17:31:36', '2019-12-30 14:08:18'),
(14, 'FV13002', 'Onion(China)(500gm)', 1, 14, 2, 20, 24.00, 'Price : per 500gram,    Quantity: 500gram 1 packet', '2019-12-29 17:32:37', '2019-12-31 00:31:23'),
(15, 'FV13003', 'Garlic(250gm)', 1, 14, 2, 150, 39.00, 'Price : per 250gram,    Quantity: 250gram 1 packet', '2019-12-29 17:34:31', NULL),
(16, 'FV13004', 'Ginger(Indian)(250gm)', 1, 14, 2, 150, 40.00, 'Price : per 250gram,    Quantity: 250gram 1 packet', '2019-12-29 17:36:12', NULL),
(17, 'FV13005', 'Potato(1kg)', 1, 14, 2, 100, 29.00, 'Price : per 1kg,    Quantity: 1kg 1 packet', '2019-12-29 17:38:06', NULL),
(18, 'FV13006', 'Green(Chili) (250gm)', 1, 14, 1, 100, 9.25, 'Price : per 250gram,    Quantity: 250gram 1 packet', '2019-12-29 17:42:03', '2019-12-29 18:46:49'),
(19, 'SC62001', 'Bombay Sweets Ring Chips(22gm)', 6, 11, 8, 100, 9.25, '22g 1 packet', '2019-12-29 17:50:58', NULL),
(20, 'SC62002', 'Alooz Waves Hot Flavour Potato Chips(22gm)', 6, 11, 8, 50, 14.25, '22g 1 packet', '2019-12-29 17:52:50', NULL),
(21, 'DM82001', 'Aarong Dairy Full Cream Milk Powder(500gm)', 7, 12, 10, 50, 270.00, 'Price : per 500gram,    Quantity: 500gram 1 packet', '2019-12-29 17:59:14', NULL),
(22, 'DM82002', 'Milk Vita Liquid(1ltr)', 7, 12, 10, 50, 62.50, 'Price : per 1liter,    Quantity: 1liter 1 packet', '2019-12-29 18:00:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` bigint(20) UNSIGNED NOT NULL,
  `sct_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sct_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `cat_id`, `sct_name`, `sct_description`, `created_at`, `updated_at`) VALUES
(1, 1, 'Dry', 'Dry Fruits', NULL, NULL),
(2, 1, 'Fresh', 'Fresh', NULL, NULL),
(3, 2, 'Meat', 'Meat', NULL, NULL),
(4, 2, 'Fish', 'Fish', NULL, NULL),
(5, 3, 'Soft', 'Soft Drinks', NULL, NULL),
(6, 4, 'Mobile', 'Mobile', NULL, NULL),
(7, 4, 'Others', 'Others', NULL, NULL),
(8, 5, 'Men(T Shirt)', 'Men\'s Fashion', NULL, NULL),
(9, 5, 'Woman(Tshirt)', 'Woman(Tshirt)', NULL, NULL),
(10, 6, 'Frozen Fruit', 'Frozen Fruit', NULL, NULL),
(11, 6, 'Chips', 'Chips', NULL, NULL),
(12, 7, 'Milk', 'Milk', NULL, NULL),
(13, 7, 'Cheese', 'Cheese', NULL, NULL),
(14, 1, 'Vegetables', 'Vegetables', '2019-12-29 23:29:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `s_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `s_id`, `s_name`, `s_phone`, `s_address`, `description`, `created_at`, `updated_at`) VALUES
(1, 'FD1', 'Md Fahim', '01515297427', 'Khilkhet Dhaka', 'Dry Fruits Suppiler', NULL, '2019-12-29 18:02:55'),
(2, 'FF1', 'Md Rashaduzzaman', '01521326372', 'Khilkhet Dhaka', 'Fresh Fruit Supplier', NULL, '2019-12-29 18:05:12'),
(3, 'MF1', 'Shanto', '01521032834', 'Mirpur Dhaka', 'Fresh Meat Supplier', NULL, NULL),
(4, 'MF2', 'Nahid Hasan', '01521552958', 'Uttara Dhaka', 'Fresh fish Supplier', NULL, NULL),
(5, 'DS01', 'Khandaker', '01521320834', 'Mirpur Dhaka', 'Soft drinks Supplier', NULL, NULL),
(6, 'EM01', 'Nakib hasan', '01521857822', 'Uttara Dhaka', 'Mobile and electronics', NULL, NULL),
(7, 'FAS01', 'Anik Khan', '01527856562', 'Mirpur Dhaka', 'T shirt seller', NULL, NULL),
(8, 'SNA01', 'NIjhum Talukdar', '01910527513', 'Tongi, Dhaka', 'Snacks Supplier', NULL, NULL),
(9, 'DAI01', 'Md Chooton Ahmed', '01521658752', 'Dhaka, Bangladesh', 'Dairy Products Supplier', NULL, NULL),
(10, 'DAI02', 'Anik Hasan', '01521320835', 'Uttara Dhaka', 'Dairy Products Supplier', '2019-12-29 22:41:23', NULL),
(11, 'FD100001', 'Abir', '010515297427', 'dhaka', 'dry fruit supplier', '2019-12-30 14:35:10', NULL),
(12, 'SF150001', 'Anik Khan', '01515297427', 'Dhaka', 'Vegeables Supplier', '2019-12-30 17:24:54', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Azizul Isalm Abir', 'azizulabir1610@gmail.com', NULL, '$2y$10$ElaecvKfsxh/Pgq3/RcHs.DoajIIXCgotVyMupvoKxuWD5rZPF.1m', 'pnKjpA07EcGsnXkRU8epPYToyNWryv9yCWbvK6DI94UF2gS5QwvQeILAvcrX', '2019-12-29 17:02:13', '2019-12-29 17:02:13'),
(2, 'Md Rashaduzzaman', 'rimu@gamil.com', NULL, '$2y$10$RiZPA3kAGXappDkR9BxhLuSTvKoq1O8IoE5PJ2pdZLNbFbRQeZUr2', NULL, '2019-12-29 17:29:21', '2019-12-29 17:29:21'),
(3, 'Md Fahim', 'fahim@gmail.com', NULL, '$2y$10$JJCWDE87PugMowBGFEqrg.NzLA2qkWjpX45BeZQik5YUdKCul99y2', 'AAdQBRPFVT3KMedDmgiBmmSvn8UghraGBoad17v7Ly8dTuM3OosAdDSNBvQ5', '2019-12-29 17:34:07', '2019-12-29 17:34:07'),
(4, 'Shanto', 'shanto@gmail.com', NULL, '$2y$10$ZeV0XBB3xLmNHJXwg5v0cemk1ASd.Y5a4qU0L4rNBJIuGZnLXAFZO', 'RBOirPM6dyIyssrorGmGQzyq7WVMz4ytlhDsDUczonhzr77RyqQ4sENDEKdU', '2019-12-29 17:37:27', '2019-12-29 17:37:27'),
(5, 'Rakib Hasan', 'rakibhasan@gmail.com', NULL, '$2y$10$BUMvK.RXv8SFG4/vSCt1cuTNvgcfQZXsN/idJzksEcjRbjtFQrGie', NULL, '2019-12-30 23:41:48', '2019-12-30 23:41:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_infos`
--
ALTER TABLE `emp_infos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `emp_infos_emp_user_id_foreign` (`emp_user_id`);

--
-- Indexes for table `emp_jobs`
--
ALTER TABLE `emp_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `emp_jobs_emp_id_foreign` (`emp_id`),
  ADD KEY `emp_jobs_position_id_foreign` (`position_id`);

--
-- Indexes for table `emp_positions`
--
ALTER TABLE `emp_positions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_contact_infos`
--
ALTER TABLE `e_contact_infos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `e_contact_infos_ec_user_id_foreign` (`ec_user_id`);

--
-- Indexes for table `e_emergancy_infos`
--
ALTER TABLE `e_emergancy_infos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `e_emergancy_infos_ee_user_id_foreign` (`ee_user_id`);

--
-- Indexes for table `e_personal_infos`
--
ALTER TABLE `e_personal_infos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `e_personal_infos_ep_user_id_foreign` (`ep_user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderdetails_product_id_foreign` (`product_id`),
  ADD KEY `orderdetails_order_id_foreign` (`order_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_sp_id_foreign` (`sp_id`);

--
-- Indexes for table `return_products`
--
ALTER TABLE `return_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `return_products_product_id_foreign` (`product_id`),
  ADD KEY `return_products_order_id_foreign` (`order_id`),
  ADD KEY `return_products_customer_id_foreign` (`customer_id`),
  ADD KEY `return_products_seller_id_foreign` (`seller_id`),
  ADD KEY `return_products_refunder_id_foreign` (`refunder_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD KEY `role_user_role_id_foreign` (`role_id`),
  ADD KEY `role_user_user_id_foreign` (`user_id`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stocks_p_code_unique` (`p_code`),
  ADD KEY `stocks_fsup_id_foreign` (`fsup_id`),
  ADD KEY `stocks_fcat_id_foreign` (`fcat_id`),
  ADD KEY `stocks_fscat_id_foreign` (`fscat_id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub_categories_cat_id_foreign` (`cat_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `suppliers_s_id_unique` (`s_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `emp_infos`
--
ALTER TABLE `emp_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emp_jobs`
--
ALTER TABLE `emp_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `emp_positions`
--
ALTER TABLE `emp_positions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `e_contact_infos`
--
ALTER TABLE `e_contact_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `e_emergancy_infos`
--
ALTER TABLE `e_emergancy_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `e_personal_infos`
--
ALTER TABLE `e_personal_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `return_products`
--
ALTER TABLE `return_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `emp_infos`
--
ALTER TABLE `emp_infos`
  ADD CONSTRAINT `emp_infos_emp_user_id_foreign` FOREIGN KEY (`emp_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `emp_jobs`
--
ALTER TABLE `emp_jobs`
  ADD CONSTRAINT `emp_jobs_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `emp_jobs_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `emp_positions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `e_contact_infos`
--
ALTER TABLE `e_contact_infos`
  ADD CONSTRAINT `e_contact_infos_ec_user_id_foreign` FOREIGN KEY (`ec_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `e_emergancy_infos`
--
ALTER TABLE `e_emergancy_infos`
  ADD CONSTRAINT `e_emergancy_infos_ee_user_id_foreign` FOREIGN KEY (`ee_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `e_personal_infos`
--
ALTER TABLE `e_personal_infos`
  ADD CONSTRAINT `e_personal_infos_ep_user_id_foreign` FOREIGN KEY (`ep_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `orderdetails_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orderdetails_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `stocks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_sp_id_foreign` FOREIGN KEY (`sp_id`) REFERENCES `stocks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `return_products`
--
ALTER TABLE `return_products`
  ADD CONSTRAINT `return_products_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `return_products_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `return_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `stocks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `return_products_refunder_id_foreign` FOREIGN KEY (`refunder_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `return_products_seller_id_foreign` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `stocks`
--
ALTER TABLE `stocks`
  ADD CONSTRAINT `stocks_fcat_id_foreign` FOREIGN KEY (`fcat_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `stocks_fscat_id_foreign` FOREIGN KEY (`fscat_id`) REFERENCES `sub_categories` (`id`),
  ADD CONSTRAINT `stocks_fsup_id_foreign` FOREIGN KEY (`fsup_id`) REFERENCES `suppliers` (`id`);

--
-- Constraints for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD CONSTRAINT `sub_categories_cat_id_foreign` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
